const express = require("express");
const bodyParser = require("body-parser");

const app = express();
const port = 3000;

app.use(bodyParser.json());

app.post("/analyze-symptoms", (req, res) => {
    const userSymptoms = req.body.symptoms;
    const botResponse = getBotResponse(userSymptoms);
    res.json({ response: botResponse });
});

function getBotResponse(symptoms) {
    // Simulate disease information (replace this with real disease information)
    const diseases = [
        { name: "Flu", symptoms: ["fever", "cough", "body aches"] },
        { name: "Cold", symptoms: ["runny nose", "sneezing", "sore throat"] },
        // Add more disease information as needed
    ];

    // Check symptoms against known diseases
    for (const disease of diseases) {
        if (symptomsMatch(symptoms, disease.symptoms)) {
            return `It seems like you may have ${disease.name}. Please consult with a healthcare professional for a proper diagnosis.`;
        }
    }

    return "I'm not sure about your symptoms. Please consult with a healthcare professional for accurate advice.";
}

function symptomsMatch(userSymptoms, diseaseSymptoms) {
    // Check if user symptoms match disease symptoms
    return userSymptoms.some(symptom => diseaseSymptoms.includes(symptom.toLowerCase()));
}

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
