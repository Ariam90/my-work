const chatBox = document.getElementById("chat-box");
const userInput = document.getElementById("user-input");

function sendMessage() {
    const userMessage = userInput.value.trim();
    if (userMessage === "") return;

    displayMessage("user", userMessage);

    // Simulate a request to the server with user symptoms
    // Replace this with an actual API call in a real-world scenario
    simulateServerRequest(userMessage);
    
    // Clear the user input
    userInput.value = "";
}

function displayMessage(sender, message) {
    const messageElement = document.createElement("div");
    messageElement.classList.add(sender);
    messageElement.textContent = message;
    chatBox.appendChild(messageElement);

    // Scroll to the bottom of the chat box
    chatBox.scrollTop = chatBox.scrollHeight;
}

function displayBotResponse(response) {
    displayMessage("bot", response);
}

function simulateServerRequest(symptoms) {
    // Simulate server processing (replace this with actual server-side logic)
    setTimeout(() => {
        const botResponse = getBotResponse(symptoms);
        displayBotResponse(botResponse);
    }, 1000);
}

function getBotResponse(symptoms) {
    // Simulate disease information (replace this with real disease information)
    const diseases = [
        { name: "Flu", symptoms: ["fever", "cough", "body aches"] },
        { name: "Cold", symptoms: ["runny nose", "sneezing", "sore throat"] },
        // Add more disease information as needed
    ];

    // Check symptoms against known diseases
    for (const disease of diseases) {
        if (symptomsMatch(symptoms, disease.symptoms)) {
            return `It seems like you may have ${disease.name}. Please consult with a healthcare professional for a proper diagnosis.`;
        }
    }

    return "I'm not sure about your symptoms. Please consult with a healthcare professional for accurate advice.";
}

function symptomsMatch(userSymptoms, diseaseSymptoms) {
    // Check if user symptoms match disease symptoms
    return userSymptoms.some(symptom => diseaseSymptoms.includes(symptom.toLowerCase()));
}
